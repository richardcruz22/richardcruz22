using System;

namespace IOFix
{
    public class WeatherForecast
    {
        public DateTime Date { get; set; }

        public int Country { get; set; }

        public int Amount => 32 + (int)(Country / 0.5556);

        public string Currency { get; set; }
    }
}
